#include <stdio.h>
#include <stdlib.h>

/* Node Structure */
struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;

/* CREATE NODE (SEPARATE FUNCTION) */
struct Node* createNode(int x) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory Allocation Failed\n");
        return NULL;
    }
    newNode->data = x;
    newNode->next = newNode;   // circular link
    return newNode;
}

/* FREE NODE */
void freeNode(struct Node *node) {
    free(node);
}

/* INSERT AT BEGINNING */
void insertAtBeginning(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    if (head == NULL) {
        head = newNode;
        return;
    }

    struct Node *temp = head;
    while (temp->next != head)
        temp = temp->next;

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

/* INSERT AT END */
void insertAtEnd(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    if (head == NULL) {
        head = newNode;
        return;
    }

    struct Node *temp = head;
    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
}

/* INSERT AT GIVEN POSITION */
void insertAtPosition(int x, int pos) {
    if (pos <= 0) {
        printf("Invalid Position\n");
        return;
    }

    if (pos == 1) {
        insertAtBeginning(x);
        return;
    }

    struct Node *newNode = createNode(x);
    struct Node *temp = head;

    for (int i = 1; i < pos - 1 && temp->next != head; i++)
        temp = temp->next;

    newNode->next = temp->next;
    temp->next = newNode;
}

/* DELETE AT BEGINNING */
void deleteAtBeginning() {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    if (head->next == head) {
        freeNode(head);
        head = NULL;
        return;
    }

    struct Node *temp = head;
    while (temp->next != head)
        temp = temp->next;

    struct Node *del = head;
    head = head->next;
    temp->next = head;
    freeNode(del);
}

/* DELETE AT END */
void deleteAtEnd() {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    if (head->next == head) {
        freeNode(head);
        head = NULL;
        return;
    }

    struct Node *temp = head;
    while (temp->next->next != head)
        temp = temp->next;

    freeNode(temp->next);
    temp->next = head;
}

/* DELETE AT GIVEN POSITION */
void deleteAtPosition(int pos) {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    if (pos == 1) {
        deleteAtBeginning();
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp->next != head; i++)
        temp = temp->next;

    if (temp->next == head) {
        printf("Invalid Position\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;
    freeNode(del);
}

/* DISPLAY LIST */
void display() {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    struct Node *temp = head;
    printf("Circular Linked List: ");

    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != head);

    printf("(HEAD)\n");
}

/* MAIN */
int main() {
    insertAtBeginning(10);
    insertAtEnd(20);
    insertAtEnd(30);
    insertAtBeginning(5);

    display();

    deleteAtBeginning();
    deleteAtEnd();

    display();

    return 0;
}
