#include <stdio.h>
#define MAX 5

int stack[MAX];
int top = -1;

/* Basic Operations */
void push(int item) {
    if (top == MAX - 1) {
        printf("Stack Overflow\n");
        return;
    }
    stack[++top] = item;
    printf("Pushed %d\n", item);
}

void pop() {
    if (top == -1) {
        printf("Stack Underflow\n");
        return;
    }
    printf("Popped %d\n", stack[top--]);
}
void removeDuplicates() {
    if (top == -1) {
        printf("Stack is Empty\n");
        return;
    }

    for (int i = 0; i <= top; i++) {
        for (int j = i + 1; j <= top; j++) {
            if (stack[i] == stack[j]) {
                /* shift elements left */
                for (int k = j; k < top; k++) {
                    stack[k] = stack[k + 1];
                }
                top--;   // reduce stack size
                j--;     // check same position again
            }
        }
    }

    printf("Duplicate elements removed from stack\n");
}

void display() {
    if (top == -1) {
        printf("Stack is Empty\n");
        return;
    }
    printf("Stack elements:\n");
    for (int i = top; i >= 0; i--)
        printf("%d ", stack[i]);
    printf("\n");
}

/* Extra Operations */
void peek() {
    if (top == -1)
        printf("Stack is Empty\n");
    else
        printf("Top element: %d\n", stack[top]);
}

void isEmpty() {
    if (top == -1)
        printf("Stack is Empty\n");
    else
        printf("Stack is NOT Empty\n");
}

void isFull() {
    if (top == MAX - 1)
        printf("Stack is Full\n");
    else
        printf("Stack is NOT Full\n");
}

void reverse() {
    int i, j, temp;
    for (i = 0, j = top; i < j; i++, j--) {
        temp = stack[i];
        stack[i] = stack[j];
        stack[j] = temp;
    }
    printf("Stack Reversed\n");
}

void findMax() {
    if (top == -1) {
        printf("Stack is Empty\n");
        return;
    }
    int max = stack[0];
    for (int i = 1; i <= top; i++)
        if (stack[i] > max)
            max = stack[i];
    printf("Maximum element: %d\n", max);
}

void findMin() {
    if (top == -1) {
        printf("Stack is Empty\n");
        return;
    }
    int min = stack[0];
    for (int i = 1; i <= top; i++)
        if (stack[i] < min)
            min = stack[i];
    printf("Minimum element: %d\n", min);
}

void ascending() {
    int temp;
    for (int i = 0; i <= top; i++) {
        for (int j = i + 1; j <= top; j++) {
            if (stack[i] > stack[j]) {
                temp = stack[i];
                stack[i] = stack[j];
                stack[j] = temp;
            }
        }
    }
    printf("Stack sorted in Ascending Order\n");
}


int main() {
    int choice, item;

    while (1) {
        printf("\n1.Push 2.Pop 3.Display 4.Peek 5.isEmpty 6.isFull");
        printf("\n7.Reverse 8.Max 9.Min 10.Ascending 11.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: printf("Enter element: "); scanf("%d", &item); push(item); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: peek(); break;
            case 5: isEmpty(); break;
            case 6: isFull(); break;
            case 7: reverse(); break;
            case 8: findMax(); break;
            case 9: findMin(); break;
            case 10: ascending(); break;
            case 11: return 0;
            default: printf("Invalid choice\n");
        }
    }
}
//gcc FILE.c -o FILE
//.\FILE