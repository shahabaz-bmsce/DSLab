#include <stdio.h>
#include <stdlib.h>

/* Node Structure */
struct Node {
    int data;
    struct Node *prev;
    struct Node *next;
};

struct Node *head = NULL;

/* CREATE NODE */
struct Node* createNode(int x) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    newNode->data = x;
    newNode->prev = newNode->next = NULL;
    return newNode;
}

/* FREE NODE */
void freeNode(struct Node *node) {
    free(node);
}

/* INSERT AT BEGINNING */
void insertAtBeginning(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    if (head)
        head->prev = newNode;

    newNode->next = head;
    head = newNode;
}

/* INSERT AT END */
void insertAtEnd(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    if (!head) {
        head = newNode;
        return;
    }

    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

/* INSERT AT POSITION */
void insertAtPosition(int x, int pos) {
    if (pos == 1) {
        insertAtBeginning(x);
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp; i++)
        temp = temp->next;

    if (!temp) {
        printf("Invalid position\n");
        return;
    }

    struct Node *newNode = createNode(x);
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next)
        temp->next->prev = newNode;

    temp->next = newNode;
}

/* INSERT AFTER VALUE */
void insertAfterValue(int val, int x) {
    struct Node *temp = head;
    while (temp && temp->data != val)
        temp = temp->next;

    if (!temp) {
        printf("Value not found\n");
        return;
    }

    struct Node *newNode = createNode(x);
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next)
        temp->next->prev = newNode;

    temp->next = newNode;
}

/* INSERT BEFORE VALUE */
void insertBeforeValue(int val, int x) {
    if (!head) return;

    if (head->data == val) {
        insertAtBeginning(x);
        return;
    }

    struct Node *temp = head;
    while (temp && temp->data != val)
        temp = temp->next;

    if (!temp) {
        printf("Value not found\n");
        return;
    }

    struct Node *newNode = createNode(x);
    newNode->prev = temp->prev;
    newNode->next = temp;

    temp->prev->next = newNode;
    temp->prev = newNode;
}

/* DELETE AT BEGINNING */
void deleteAtBeginning() {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    head = head->next;

    if (head)
        head->prev = NULL;

    freeNode(temp);
}

/* DELETE AT END */
void deleteAtEnd() {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;

    if (temp->prev)
        temp->prev->next = NULL;
    else
        head = NULL;

    freeNode(temp);
}

/* DELETE AT POSITION */
void deleteAtPosition(int pos) {
    if (!head) return;

    if (pos == 1) {
        deleteAtBeginning();
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos && temp; i++)
        temp = temp->next;

    if (!temp) {
        printf("Invalid position\n");
        return;
    }

    temp->prev->next = temp->next;
    if (temp->next)
        temp->next->prev = temp->prev;

    freeNode(temp);
}

/* DELETE AFTER VALUE */
void deleteAfterValue(int val) {
    struct Node *temp = head;
    while (temp && temp->data != val)
        temp = temp->next;

    if (!temp || !temp->next) {
        printf("Deletion not possible\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;

    if (del->next)
        del->next->prev = temp;

    freeNode(del);
}

/* DELETE BEFORE VALUE */
void deleteBeforeValue(int val) {
    if (!head || head->data == val) return;

    struct Node *temp = head->next;
    while (temp && temp->data != val)
        temp = temp->next;

    if (!temp || !temp->prev) return;

    struct Node *del = temp->prev;

    if (del->prev)
        del->prev->next = temp;
    else
        head = temp;

    temp->prev = del->prev;
    freeNode(del);
}

/* FIND MIDDLE NODE */
void findMiddle() {
    struct Node *slow = head, *fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    if (slow)
        printf("Middle node: %d\n", slow->data);
}

/* REVERSE LIST */
void reverse() {
    struct Node *curr = head, *temp = NULL;

    while (curr) {
        temp = curr->prev;
        curr->prev = curr->next;
        curr->next = temp;
        curr = curr->prev;
    }

    if (temp)
        head = temp->prev;
}

/* BUBBLE SORT */
void bubbleSort() {
    struct Node *i, *j;
    for (i = head; i; i = i->next)
        for (j = i->next; j; j = j->next)
            if (i->data > j->data) {
                int t = i->data;
                i->data = j->data;
                j->data = t;
            }
}

/* DISPLAY */
void display() {
    if (!head) {
        printf("List is empty\n");
        return;
    }
    struct Node *temp = head;
    while (temp) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

/* MAIN – SWITCH CASE */
int main() {
    int ch, x, pos, val;

    while (1) {
        printf("\n1.Insert Beg  2.Insert End  3.Insert Pos\n");
        printf("4.Insert After 5.Insert Before\n");
        printf("6.Delete Beg 7.Delete End 8.Delete Pos\n");
        printf("9.Delete After 10.Delete Before\n");
        printf("11.Middle 12.Reverse 13.Sort\n");
        printf("14.Display 15.Exit\n");
        printf("Choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1: scanf("%d",&x); insertAtBeginning(x); break;
            case 2: scanf("%d",&x); insertAtEnd(x); break;
            case 3: scanf("%d%d",&x,&pos); insertAtPosition(x,pos); break;
            case 4: scanf("%d%d",&val,&x); insertAfterValue(val,x); break;
            case 5: scanf("%d%d",&val,&x); insertBeforeValue(val,x); break;
            case 6: deleteAtBeginning(); break;
            case 7: deleteAtEnd(); break;
            case 8: scanf("%d",&pos); deleteAtPosition(pos); break;
            case 9: scanf("%d",&val); deleteAfterValue(val); break;
            case 10: scanf("%d",&val); deleteBeforeValue(val); break;
            case 11: findMiddle(); break;
            case 12: reverse(); break;
            case 13: bubbleSort(); break;
            case 14: display(); break;
            case 15: return 0;
            default: printf("Invalid choice\n");
        }
    }
}
