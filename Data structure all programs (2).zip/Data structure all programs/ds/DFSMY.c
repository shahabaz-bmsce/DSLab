#include <stdio.h>

#define MAX 20

int adj[MAX][MAX], visited[MAX] = {0}, n;

/* DFS function */
void DFS(int v) {
    visited[v] = 1;
    for (int i = 0; i < n; i++) {
        if (adj[v][i] == 1 && visited[i] == 0) {
            DFS(i);
        }
    }
}

int main() {
    int start = 0, connected = 1;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &adj[i][j]);

    DFS(start);

    for (int i = 0; i < n; i++) {
        if (visited[i] == 0) {
            connected = 0;
            break;
        }
    }

    if (connected)
        printf("Graph is CONNECTED\n");
    else
        printf("Graph is NOT CONNECTED\n");

    return 0;
} 

//gcc FILE.c -o FILE
//.\FILE