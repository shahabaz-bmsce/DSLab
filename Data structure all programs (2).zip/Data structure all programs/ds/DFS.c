#include <stdio.h>
#define MAX 20
int visited[MAX],adj[MAX][MAX];

void DFS(int v,int n){
    visited[v]=1;
    for(int i=0;i<n;i++){
        if(adj[v][i] && !visited[i]){
            DFS(i,n);
        }
    }
}

int main(){
    int n;
    printf("Enter number of vertices: ");
    scanf("%d",&n);
    printf("Enter Adjacency matrix of the graph: ");
    for(int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            scanf("%d",&adj[i][j]);
        }
    }
    for(int i=0;i<n;i++){
        visited[i]=0;
    }
    DFS(0,n);
    int connected=1;
    for(int i=0;i<n;i++){
        if (!visited[i]){
            connected=0;
            break;
        }
    }
    if(connected==1){
        printf("Graph is connected.\n");}
    else{
        printf("Graph is not connected.\n");}
    return 0;
}