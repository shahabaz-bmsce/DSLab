/*There are N petrol pumps arranged in a circle.
Each petrol pump provides:

Amount of petrol

Distance to the next petrol pump
INPUT:
Enter number of petrol pumps: 4
Enter petrol and distance:
6 4
3 6
7 3
4 5 
OUTPUT:
Start from petrol pump: 2
*/

#include <stdio.h>

int main() {
    int n;
    int petrol[100], dist[100];

    printf("Enter number of petrol pumps: ");
    scanf("%d", &n);

    printf("Enter petrol and distance:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &petrol[i], &dist[i]);
    }

    int start = 0;
    int balance = 0;
    int deficit = 0;

    for (int i = 0; i < n; i++) {
        balance += petrol[i] - dist[i];

        if (balance < 0) {
            start = i + 1;
            deficit += balance;
            balance = 0;
        }
    }

    if (balance + deficit >= 0)
        printf("Start from petrol pump: %d\n", start);
    else
        printf("No possible tour\n");

    return 0;
}
