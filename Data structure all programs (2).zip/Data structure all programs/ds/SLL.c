#include <stdio.h>
#include <stdlib.h>

/* Node Structure */
struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;

/* CREATE NODE (SEPARATE FUNCTION) */
struct Node* createNode(int x) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory Allocation Failed\n");
        return NULL;
    }
    newNode->data = x;
    newNode->next = NULL;
    return newNode;
}

/* DELETE NODE (SEPARATE FUNCTION) */
void freeNode(struct Node *node) {
    free(node);
}

/* INSERT AT BEGINNING */
void insertAtBeginning(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    newNode->next = head;
    head = newNode;
}

/* INSERT AT END */
void insertAtEnd(int x) {
    struct Node *newNode = createNode(x);
    if (!newNode) return;

    if (head == NULL) {
        head = newNode;
        return;
    }

    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
}
/* INSERT AT GIVEN POSITION */
void insertAtPosition(int x, int pos) {
    if (pos <= 0) {
        printf("Invalid Position\n");
        return;
    }

    if (pos == 1) {
        insertAtBeginning(x);
        return;
    }

    struct Node *newNode = createNode(x);
    if (!newNode) return;

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp != NULL; i++)
        temp = temp->next;

    if (temp == NULL) {
        printf("Invalid Position\n");
        freeNode(newNode);
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}


/* DELETE AT BEGINNING */
void deleteAtBeginning() {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    struct Node *temp = head;
    head = head->next;
    freeNode(temp);
}

/* DELETE AT END */
void deleteAtEnd() {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    if (head->next == NULL) {
        freeNode(head);
        head = NULL;
        return;
    }

    struct Node *temp = head;
    while (temp->next->next)
        temp = temp->next;

    freeNode(temp->next);
    temp->next = NULL;
}

/* DELETE AT GIVEN POSITION */
void deleteAtPosition(int pos) {
    if (head == NULL) {
        printf("List is Empty\n");
        return;
    }

    if (pos == 1) {
        deleteAtBeginning();
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp->next; i++)
        temp = temp->next;

    if (temp->next == NULL) {
        printf("Invalid Position\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;
    freeNode(del);
}

/* DISPLAY LIST */
void display() {
    struct Node *temp = head;
    if (!temp) {
        printf("List is Empty\n");
        return;
    }

    printf("Linked List: ");
    while (temp) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

/* MAIN */
int main() {
    insertAtBeginning(10);
    insertAtEnd(20);
    insertAtEnd(30);
    insertAtBeginning(5);

    display();

    deleteAtBeginning();
    deleteAtEnd();

    display();

    return 0;
}
