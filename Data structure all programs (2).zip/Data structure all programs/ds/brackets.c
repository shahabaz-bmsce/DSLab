#include <stdio.h>
#include <string.h>

#define MAX 100

char stack[MAX];
int top = -1;

void push(char c) {
    stack[++top] = c;
}

char pop() {
    return stack[top--];
}

int isMatching(char open, char close) {
    if (open == '(' && close == ')') return 1;
    if (open == '{' && close == '}') return 1;
    if (open == '[' && close == ']') return 1;
    return 0;
}

int isBalanced(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        char ch = str[i];

        if (ch == '(' || ch == '{' || ch == '[') {
            push(ch);
        } else if (ch == ')' || ch == '}' || ch == ']') {
            if (top == -1)
                return 0;
            char open = pop();
            if (!isMatching(open, ch))
                return 0;
        }
    }
    return (top == -1);
}

int main() {
    char str[100];

    printf("Enter bracket string: ");
    scanf("%s", str);

    if (isBalanced(str))
        printf("YES\n");
    else
        printf("NO\n");

    return 0;
}

//gcc FILE.c -o FILE
//.\FILE