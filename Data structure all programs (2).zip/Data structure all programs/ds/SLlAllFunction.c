#include <stdio.h>
#include <stdlib.h>

/* Node structure */
struct Node {
    int data;
    struct Node *next;
};

/* ---------- INSERT AT END ---------- */
void insertEnd(struct Node **head, int x) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = x;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
        return;
    }

    struct Node *temp = *head;
    while (temp->next)
        temp = temp->next;
    temp->next = newNode;
}

/* ---------- DISPLAY ---------- */
void display(struct Node *head) {
    if (!head) {
        printf("List is empty\n");
        return;
    }
    while (head) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

/* ---------- SORT ASCENDING (Two pointers + while) ---------- */
void ascendingOrder(struct Node *head) {
    struct Node *cur, *move;
    int temp;

    if (!head) {
        printf("List is empty\n");
        return;
    }

    cur = head;
    while (cur) {
        move = cur->next;
        while (move) {
            if (cur->data > move->data) {
                temp = cur->data;
                cur->data = move->data;
                move->data = temp;
            }
            move = move->next;
        }
        cur = cur->next;
    }
    printf("List sorted in ascending order\n");
}

/* ---------- CHECK ASCENDING ---------- */
void checkAscending(struct Node *head) {
    if (!head || !head->next) {
        printf("List is in ascending order\n");
        return;
    }

    while (head->next) {
        if (head->data > head->next->data) {
            printf("List is NOT in ascending order\n");
            return;
        }
        head = head->next;
    }
    printf("List is in ascending order\n");
}

/* ---------- FIND MIN ---------- */
void findMin(struct Node *head) {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    int min = head->data;
    while (head) {
        if (head->data < min)
            min = head->data;
        head = head->next;
    }
    printf("Minimum element = %d\n", min);
}

/* ---------- FIND MAX ---------- */
void findMax(struct Node *head) {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    int max = head->data;
    while (head) {
        if (head->data > max)
            max = head->data;
        head = head->next;
    }
    printf("Maximum element = %d\n", max);
}

/* ---------- REVERSE LIST ---------- */
void reverseList(struct Node **head) {
    struct Node *prev = NULL, *curr = *head, *next;

    while (curr) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    *head = prev;
    printf("List reversed\n");
}

/* ---------- REMOVE DUPLICATES (Unsorted list) ---------- */
void removeDuplicates(struct Node *head) {
    struct Node *cur, *move, *prev;

    cur = head;
    while (cur) {
        prev = cur;
        move = cur->next;

        while (move) {
            if (cur->data == move->data) {
                prev->next = move->next;
                free(move);
                move = prev->next;
            } else {
                prev = move;
                move = move->next;
            }
        }
        cur = cur->next;
    }
    printf("Duplicates removed\n");
}

/* ---------- CONCATENATE ---------- */
void concatenate(struct Node **head1, struct Node *head2) {
    if (*head1 == NULL) {
        *head1 = head2;
        return;
    }

    struct Node *temp = *head1;
    while (temp->next)
        temp = temp->next;
    temp->next = head2;
}

/* ---------- MAIN ---------- */
int main() {
    struct Node *list1 = NULL, *list2 = NULL;

    /* List 1 */
    insertEnd(&list1, 30);
    insertEnd(&list1, 10);
    insertEnd(&list1, 20);
    insertEnd(&list1, 10);

    /* List 2 */
    insertEnd(&list2, 40);
    insertEnd(&list2, 50);

    printf("List 1: ");
    display(list1);

    checkAscending(list1);
    findMin(list1);
    findMax(list1);

    ascendingOrder(list1);
    display(list1);

    removeDuplicates(list1);
    display(list1);

    reverseList(&list1);
    display(list1);

    concatenate(&list1, list2);
    printf("After Concatenation: ");
    display(list1);

    return 0;
}
