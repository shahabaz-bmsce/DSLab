#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Node structure */
struct Node {
    char name[30];
    char mobile[15];
    struct Node *next;
};

struct Node *head = NULL;

/* ---------- CREATE NODE ---------- */
struct Node* createNode(char name[], char mobile[]) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    strcpy(newNode->name, name);
    strcpy(newNode->mobile, mobile);
    newNode->next = NULL;
    return newNode;
}

/* ---------- INSERT AT FRONT ---------- */
void insertFront(char name[], char mobile[]) {
    struct Node *newNode = createNode(name, mobile);
    newNode->next = head;
    head = newNode;
}

/* ---------- INSERT AT END ---------- */
void insertEnd(char name[], char mobile[]) {
    struct Node *newNode = createNode(name, mobile);
    if (!head) {
        head = newNode;
        return;
    }
    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;
    temp->next = newNode;
}

/* ---------- INSERT AT POSITION ---------- */
void insertAtPosition(char name[], char mobile[], int pos) {
    if (pos == 1) {
        insertFront(name, mobile);
        return;
    }

    struct Node *newNode = createNode(name, mobile);
    struct Node *temp = head;

    for (int i = 1; i < pos - 1 && temp; i++)
        temp = temp->next;

    if (!temp) {
        printf("Invalid position\n");
        free(newNode);
        return;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

/* ---------- INSERT AFTER PARTICULAR NODE (BY MOBILE) ---------- */
void insertAfter(char targetMobile[], char name[], char mobile[]) {
    struct Node *temp = head;
    while (temp && strcmp(temp->mobile, targetMobile) != 0)
        temp = temp->next;

    if (!temp) {
        printf("Target node not found\n");
        return;
    }

    struct Node *newNode = createNode(name, mobile);
    newNode->next = temp->next;
    temp->next = newNode;
}

/* ---------- DELETE FRONT ---------- */
void deleteFront() {
    if (!head) {
        printf("List is empty\n");
        return;
    }
    struct Node *temp = head;
    head = head->next;
    free(temp);
}

/* ---------- DELETE REAR ---------- */
void deleteRear() {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    if (!head->next) {
        free(head);
        head = NULL;
        return;
    }

    struct Node *temp = head;
    while (temp->next->next)
        temp = temp->next;

    free(temp->next);
    temp->next = NULL;
}

/* ---------- DELETE AT POSITION ---------- */
void deleteAtPosition(int pos) {
    if (pos == 1) {
        deleteFront();
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp; i++)
        temp = temp->next;

    if (!temp || !temp->next) {
        printf("Invalid position\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;
    free(del);
}

/* ---------- DELETE PARTICULAR NODE (BY MOBILE) ---------- */
void deleteByMobile(char mobile[]) {
    if (!head) return;

    if (strcmp(head->mobile, mobile) == 0) {
        deleteFront();
        return;
    }

    struct Node *temp = head;
    while (temp->next && strcmp(temp->next->mobile, mobile) != 0)
        temp = temp->next;

    if (!temp->next) {
        printf("Node not found\n");
        return;
    }

    struct Node *del = temp->next;
    temp->next = del->next;
    free(del);
}

/* ---------- REMOVE DUPLICATES (BY MOBILE) ---------- */
void removeDuplicates() {
    struct Node *cur = head, *move, *prev;

    while (cur) {
        prev = cur;
        move = cur->next;

        while (move) {
            if (strcmp(cur->mobile, move->mobile) == 0) {
                prev->next = move->next;
                free(move);
                move = prev->next;
            } else {
                prev = move;
                move = move->next;
            }
        }
        cur = cur->next;
    }
}

/* ---------- SORT ASCENDING (BY MOBILE NUMBER) ---------- */
void sortAscending() {
    struct Node *cur, *move;
    char tempName[30], tempMobile[15];

    cur = head;
    while (cur) {
        move = cur->next;
        while (move) {
            if (strcmp(cur->mobile, move->mobile) > 0) {
                strcpy(tempName, cur->name);
                strcpy(cur->name, move->name);
                strcpy(move->name, tempName);

                strcpy(tempMobile, cur->mobile);
                strcpy(cur->mobile, move->mobile);
                strcpy(move->mobile, tempMobile);
            }
            move = move->next;
        }
        cur = cur->next;
    }
}

/* ---------- SORT ALPHABETICALLY (BY NAME) ---------- */
void sortAlphabetical() {
    struct Node *cur, *move;
    char tempName[30], tempMobile[15];

    cur = head;
    while (cur) {
        move = cur->next;
        while (move) {
            if (strcmp(cur->name, move->name) > 0) {
                strcpy(tempName, cur->name);
                strcpy(cur->name, move->name);
                strcpy(move->name, tempName);

                strcpy(tempMobile, cur->mobile);
                strcpy(cur->mobile, move->mobile);
                strcpy(move->mobile, tempMobile);
            }
            move = move->next;
        }
        cur = cur->next;
    }
}

/* ---------- DISPLAY ---------- */
void display() {
    struct Node *temp = head;
    if (!temp) {
        printf("List is empty\n");
        return;
    }

    printf("\nCustomer List:\n");
    while (temp) {
        printf("Name: %-10s | Mobile: %s\n", temp->name, temp->mobile);
        temp = temp->next;
    }
}

/* ---------- MAIN ---------- */
int main() {
    insertFront("Anisha", "9876543210");
    insertEnd("Rahul", "9123456789");
    insertEnd("Anisha", "9876543210");   // duplicate
    insertAtPosition("Priya", "9988776655", 2);
    insertAfter("9123456789", "Kiran", "9000011111");

    printf("\nBefore removing duplicates:");
    display();

    removeDuplicates();

    printf("\nAfter removing duplicates:");
    display();

    sortAlphabetical();
    printf("\nAfter alphabetical sort:");
    display();

    deleteByMobile("9988776655");
    deleteRear();

    printf("\nAfter deletions:");
    display();

    return 0;
}
