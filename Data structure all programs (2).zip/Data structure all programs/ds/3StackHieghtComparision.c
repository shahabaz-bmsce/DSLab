/*You are given three stacks of cylinders with different heights.
You can remove cylinders only from the top of any stack.
Find the maximum possible height such that all three stacks have equal height.

OUTPUT: 
Enter n1 n2 n3: 5 3 4
Enter stack 1 heights (top to bottom):
3 2 1 1 1
Enter stack 2 heights (top to bottom):
4 3 2
Enter stack 3 heights (top to bottom):
1 1 4 1
*/
#include <stdio.h>
int main() {
    int n1, n2, n3;
    int s1[100], s2[100], s3[100];
    int h1 = 0, h2 = 0, h3 = 0;
    int i1 = 0, i2 = 0, i3 = 0;

    printf("Enter n1 n2 n3: ");
    scanf("%d %d %d", &n1, &n2, &n3);

    printf("Enter stack 1 heights (top to bottom):\n");
    for (int i = 0; i < n1; i++) {
        scanf("%d", &s1[i]);
        h1 += s1[i];
    }

    printf("Enter stack 2 heights (top to bottom):\n");
    for (int i = 0; i < n2; i++) {
        scanf("%d", &s2[i]);
        h2 += s2[i];
    }

    printf("Enter stack 3 heights (top to bottom):\n");
    for (int i = 0; i < n3; i++) {
        scanf("%d", &s3[i]);
        h3 += s3[i];
    }

    while (1) {
        if (i1 == n1 || i2 == n2 || i3 == n3) {
            printf("Maximum equal height: 0\n");
            break;
        }

        if (h1 == h2 && h2 == h3) {
            printf("Maximum equal height: %d\n", h1);
            break;
        }

        if (h1 >= h2 && h1 >= h3) {
            h1 -= s1[i1++];
        } else if (h2 >= h1 && h2 >= h3) {
            h2 -= s2[i2++];
        } else {
            h3 -= s3[i3++];
        }
    }

    return 0;
}
