#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int coeff;
    int exp;
    struct node *next;
} *POLY;

/* Create node */
POLY createNode(int c, int e) {
    POLY n = (POLY)malloc(sizeof(struct node));
    n->coeff = c;
    n->exp = e;
    n->next = NULL;
    return n;
}

/* Insert at end */
POLY insertEnd(POLY head, int c, int e) {
    POLY n = createNode(c, e);
    if (head == NULL)
        return n;

    POLY temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = n;
    return head;
}

/* Add two polynomials */
POLY addPoly(POLY p1, POLY p2) {
    POLY res = NULL;

    while (p1 != NULL && p2 != NULL) {
        if (p1->exp == p2->exp) {
            res = insertEnd(res, p1->coeff + p2->coeff, p1->exp);
            p1 = p1->next;
            p2 = p2->next;
        } else if (p1->exp < p2->exp) {
            res = insertEnd(res, p1->coeff, p1->exp);
            p1 = p1->next;
        } else {
            res = insertEnd(res, p2->coeff, p2->exp);
            p2 = p2->next;
        }
    }

    while (p1 != NULL) {
        res = insertEnd(res, p1->coeff, p1->exp);
        p1 = p1->next;
    }

    while (p2 != NULL) {
        res = insertEnd(res, p2->coeff, p2->exp);
        p2 = p2->next;
    }

    return res;
}

/* Display polynomial */
void display(POLY head) {
    POLY temp = head;
    while (temp != NULL) {
        printf("%dx^%d", temp->coeff, temp->exp);
        if (temp->next != NULL)
            printf(" + ");
        temp = temp->next;
    }
    printf("\n");
}

int main() {
    POLY p1 = NULL, p2 = NULL, sum = NULL;

    /* Polynomial 1: 2x^3 + 8x^4 + 5x^6 */
    p1 = insertEnd(p1, 2, 3);
    p1 = insertEnd(p1, 8, 4);
    p1 = insertEnd(p1, 5, 6);

    /* Polynomial 2: 3x^4 + 4x^6 */
    p2 = insertEnd(p2, 3, 4);
    p2 = insertEnd(p2, 4, 6);

    printf("Polynomial 1: ");
    display(p1);

    printf("Polynomial 2: ");
    display(p2);

    sum = addPoly(p1, p2);

    printf("Resultant Polynomial: ");
    display(sum);

    return 0;
}
