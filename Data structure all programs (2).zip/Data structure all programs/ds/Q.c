#include <stdio.h>
#define MAX 5

int queue[MAX];
int front = -1, rear = -1;

void insert(int item) {
    if (rear == MAX - 1) {
        printf("Queue Overflow\n");
        return;
    }
    if (front == -1)
        front = 0;
    queue[++rear] = item;
    printf("Inserted %d\n", item);
}

void delete() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }
    printf("Deleted %d\n", queue[front++]);
}

void display() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }
    printf("Queue elements: ");
    for (int i = front; i <= rear; i++)
        printf("%d ", queue[i]);
    printf("\n");
}

/* REVERSE QUEUE */
void reverse() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }

    int i = front, j = rear;
    while (i < j) {
        int temp = queue[i];
        queue[i] = queue[j];
        queue[j] = temp;
        i++;
        j--;
    }
    printf("Queue Reversed\n");
}

/* ASCENDING ORDER */
void ascending() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }

    int temp[MAX];
    int n = rear - front + 1;

    for (int i = 0; i < n; i++)
        temp[i] = queue[front + i];

    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (temp[i] > temp[j]) {
                int t = temp[i];
                temp[i] = temp[j];
                temp[j] = t;
            }

    printf("Queue in Ascending Order: ");
    for (int i = 0; i < n; i++)
        printf("%d ", temp[i]);
    printf("\n");
}

/* MAX ELEMENT */
void maxElement() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }

    int max = queue[front];
    for (int i = front + 1; i <= rear; i++)
        if (queue[i] > max)
            max = queue[i];

    printf("Maximum element: %d\n", max);
}

/* MIN ELEMENT */
void minElement() {
    if (front == -1 || front > rear) {
        printf("Queue is Empty\n");
        return;
    }

    int min = queue[front];
    for (int i = front + 1; i <= rear; i++)
        if (queue[i] < min)
            min = queue[i];

    printf("Minimum element: %d\n", min);
}

int main() {
    int choice, item;

    while (1) {
        printf("\n1.Insert\n2.Delete\n3.Display\n4.Reverse\n5.Ascending\n6.Max\n7.Min\n8.Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter element: ");
                scanf("%d", &item);
                insert(item);
                break;

            case 2:
                delete();
                break;

            case 3:
                display();
                break;

            case 4:
                reverse();
                break;

            case 5:
                ascending();
                break;

            case 6:
                maxElement();
                break;

            case 7:
                minElement();
                break;

            case 8:
                return 0;

            default:
                printf("Invalid choice\n");
        }
    }
}

//gcc FILE.c -o FILE
//.\FILE