#include <stdio.h>
#include <stdlib.h>

/* Node structure */
struct Node {
    int data;
    struct Node *next;
};

struct Node *front = NULL;
struct Node *rear  = NULL;

/* -------- CREATE NODE (SEPARATE) -------- */
struct Node* createNode(int item) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    newNode->data = item;
    newNode->next = NULL;
    return newNode;
}

/* -------- ENQUEUE (INSERT) -------- */
void enqueue(int item) {
    struct Node *newNode = createNode(item);
    if (newNode == NULL)
        return;

    if (rear == NULL) {   // queue empty
        front = rear = newNode;
    } else {
        rear->next = newNode;
        rear = newNode;
    }
    printf("Enqueued %d\n", item);
}

/* -------- DEQUEUE (DELETE) -------- */
void dequeue() {
    if (front == NULL) {
        printf("Queue Underflow\n");
        return;
    }

    struct Node *temp = front;
    printf("Dequeued %d\n", temp->data);
    front = front->next;

    if (front == NULL)    // queue becomes empty
        rear = NULL;

    free(temp);
}

/* -------- DISPLAY -------- */
void display() {
    if (front == NULL) {
        printf("Queue is Empty\n");
        return;
    }

    struct Node *temp = front;
    printf("Queue elements: ");
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

/* -------- MAIN -------- */
int main() {
    int choice, item;

    do {
        printf("\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter element: ");
                scanf("%d", &item);
                enqueue(item);
                break;

            case 2:
                dequeue();
                break;

            case 3:
                display();
                break;

            case 4:
                printf("Exiting...\n");
                break;

            default:
                printf("Invalid choice\n");
        }
    } while (choice != 4);

    return 0;
}
