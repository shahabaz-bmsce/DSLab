#include <stdio.h>
#define MAX 100

int hashTable[MAX];
int m;
int count = 0;  


void init() {
    for (int i = 0; i < m; i++)
        hashTable[i] = -1;
}


void insert(int key) {
    if (count == m) {
        printf("Hash table is FULL. Cannot insert key %d\n", key);
        return;
    }

    int index = key % m;

    while (hashTable[index] != -1) {
        index = (index + 1) % m;
    }

    hashTable[index] = key;
    count++;
}


void display() {
    printf("\nHash Table:\n");
    for (int i = 0; i < m; i++) {
        if (hashTable[i] != -1)
            printf("Address %d : %d\n", i, hashTable[i]);
        else
            printf("Address %d : EMPTY\n", i);
    }
}

int main() {
    int n, key;

    printf("Enter hash table size (m): ");
    scanf("%d", &m);

    init();

    printf("Enter number of employee records (N): ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Enter 4-digit key: ");
        scanf("%d", &key);
        insert(key);
    }

    display();
    return 0;
}
//gcc FILE.c -o FILE
//.\FILE