#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Node structure */
struct Node {
    char name[30];
    char mobile[15];
    struct Node *prev;
    struct Node *next;
};

struct Node *head = NULL;

/* ---------- CREATE NODE ---------- */
struct Node* createNode(char name[], char mobile[]) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (!newNode) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    strcpy(newNode->name, name);
    strcpy(newNode->mobile, mobile);
    newNode->prev = newNode->next = NULL;
    return newNode;
}

/* ---------- INSERT AT FRONT ---------- */
void insertFront(char name[], char mobile[]) {
    struct Node *newNode = createNode(name, mobile);
    if (!newNode) return;

    newNode->next = head;
    if (head)
        head->prev = newNode;
    head = newNode;
}

/* ---------- INSERT AT END ---------- */
void insertEnd(char name[], char mobile[]) {
    struct Node *newNode = createNode(name, mobile);
    if (!newNode) return;

    if (!head) {
        head = newNode;
        return;
    }

    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
    newNode->prev = temp;
}

/* ---------- INSERT AT POSITION ---------- */
void insertAtPosition(char name[], char mobile[], int pos) {
    if (pos == 1) {
        insertFront(name, mobile);
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos - 1 && temp; i++)
        temp = temp->next;

    if (!temp) {
        printf("Invalid position\n");
        return;
    }

    struct Node *newNode = createNode(name, mobile);
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next)
        temp->next->prev = newNode;

    temp->next = newNode;
}

/* ---------- INSERT AFTER PARTICULAR NODE (BY MOBILE) ---------- */
void insertAfter(char targetMobile[], char name[], char mobile[]) {
    struct Node *temp = head;
    while (temp && strcmp(temp->mobile, targetMobile) != 0)
        temp = temp->next;

    if (!temp) {
        printf("Target node not found\n");
        return;
    }

    struct Node *newNode = createNode(name, mobile);
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next)
        temp->next->prev = newNode;

    temp->next = newNode;
}

/* ---------- DELETE FRONT ---------- */
void deleteFront() {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    head = head->next;

    if (head)
        head->prev = NULL;

    free(temp);
}

/* ---------- DELETE REAR ---------- */
void deleteRear() {
    if (!head) {
        printf("List is empty\n");
        return;
    }

    struct Node *temp = head;
    while (temp->next)
        temp = temp->next;

    if (temp->prev)
        temp->prev->next = NULL;
    else
        head = NULL;

    free(temp);
}

/* ---------- DELETE AT POSITION ---------- */
void deleteAtPosition(int pos) {
    if (!head) return;

    if (pos == 1) {
        deleteFront();
        return;
    }

    struct Node *temp = head;
    for (int i = 1; i < pos && temp; i++)
        temp = temp->next;

    if (!temp) {
        printf("Invalid position\n");
        return;
    }

    if (temp->prev)
        temp->prev->next = temp->next;
    if (temp->next)
        temp->next->prev = temp->prev;

    free(temp);
}

/* ---------- DELETE PARTICULAR NODE (BY MOBILE) ---------- */
void deleteByMobile(char mobile[]) {
    struct Node *temp = head;

    while (temp && strcmp(temp->mobile, mobile) != 0)
        temp = temp->next;

    if (!temp) {
        printf("Node not found\n");
        return;
    }

    if (temp->prev)
        temp->prev->next = temp->next;
    else
        head = temp->next;

    if (temp->next)
        temp->next->prev = temp->prev;

    free(temp);
}

/* ---------- REMOVE DUPLICATES (BY MOBILE) ---------- */
void removeDuplicates() {
    struct Node *cur = head, *move;

    while (cur) {
        move = cur->next;
        while (move) {
            if (strcmp(cur->mobile, move->mobile) == 0) {
                struct Node *dup = move;
                move = move->next;

                if (dup->prev)
                    dup->prev->next = dup->next;
                if (dup->next)
                    dup->next->prev = dup->prev;

                free(dup);
            } else {
                move = move->next;
            }
        }
        cur = cur->next;
    }
}

/* ---------- SORT ASCENDING (BY MOBILE) ---------- */
void sortAscending() {
    struct Node *i, *j;
    char tName[30], tMobile[15];

    for (i = head; i; i = i->next) {
        for (j = i->next; j; j = j->next) {
            if (strcmp(i->mobile, j->mobile) > 0) {
                strcpy(tName, i->name);
                strcpy(tMobile, i->mobile);

                strcpy(i->name, j->name);
                strcpy(i->mobile, j->mobile);

                strcpy(j->name, tName);
                strcpy(j->mobile, tMobile);
            }
        }
    }
}

/* ---------- SORT ALPHABETICALLY (BY NAME) ---------- */
void sortAlphabetical() {
    struct Node *i, *j;
    char tName[30], tMobile[15];

    for (i = head; i; i = i->next) {
        for (j = i->next; j; j = j->next) {
            if (strcmp(i->name, j->name) > 0) {
                strcpy(tName, i->name);
                strcpy(tMobile, i->mobile);

                strcpy(i->name, j->name);
                strcpy(i->mobile, j->mobile);

                strcpy(j->name, tName);
                strcpy(j->mobile, tMobile);
            }
        }
    }
}

/* ---------- DISPLAY ---------- */
void display() {
    struct Node *temp = head;
    if (!temp) {
        printf("List is empty\n");
        return;
    }

    printf("\nCustomer List:\n");
    while (temp) {
        printf("Name: %-10s | Mobile: %s\n", temp->name, temp->mobile);
        temp = temp->next;
    }
}

/* ---------- MAIN ---------- */
int main() {
    insertFront("Anisha", "9876543210");
    insertEnd("Rahul", "9123456789");
    insertEnd("Anisha", "9876543210");   // duplicate
    insertAtPosition("Priya", "9988776655", 2);
    insertAfter("9123456789", "Kiran", "9000011111");

    printf("\nInitial List:");
    display();

    removeDuplicates();
    sortAlphabetical();

    printf("\nAfter Removing Duplicates & Alphabetical Sort:");
    display();

    deleteByMobile("9988776655");
    deleteRear();

    printf("\nAfter Deletions:");
    display();

    return 0;
}
