#include <stdio.h>
#include <stdlib.h>

#define MAX 10

int arr[MAX];
int top1 = -1;
int top2 = MAX;

void push1(int x) {
    if (top1 + 1 == top2) {
        printf("Stack Overflow\n");
        return;
    }
    arr[++top1] = x;
}

void push2(int x) {
    if (top1 + 1 == top2) {
        printf("Stack Overflow\n");
        return;
    }
    arr[--top2] = x;
}

int pop1() {
    if (top1 == -1) {
        printf("Stack 1 Underflow\n");
        return -1;
    }
    return arr[top1--];
}

int pop2() {
    if (top2 == MAX) {
        printf("Stack 2 Underflow\n");
        return -1;
    }
    return arr[top2++];
}

void display() {
    printf("\nStack 1: ");
    for (int i = top1; i >= 0; i--)
        printf("%d ", arr[i]);

    printf("\nStack 2: ");
    for (int i = top2; i < MAX; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main() {
    push1(10);
    push1(20);
    push2(30);
    push2(40);

    display();

    printf("\nPopped from Stack 1: %d\n", pop1());
    printf("Popped from Stack 2: %d\n", pop2());

    display();

    return 0;
}
