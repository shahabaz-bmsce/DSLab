#include <stdio.h>
#define MAX 5

int cq[MAX];
int front = -1, rear = -1;

/* CHECK EMPTY */
int isEmpty() {
    return (front == -1);
}

/* ENQUEUE */
void enqueue(int item) {
    if ((rear + 1) % MAX == front) {
        printf("Circular Queue Overflow\n");
        return;
    }

    if (front == -1)
        front = rear = 0;
    else
        rear = (rear + 1) % MAX;

    cq[rear] = item;
    printf("Enqueued %d\n", item);
}

/* DEQUEUE */
void dequeue() {
    if (isEmpty()) {
        printf("Circular Queue Empty\n");
        return;
    }

    printf("Dequeued %d\n", cq[front]);

    if (front == rear)
        front = rear = -1;
    else
        front = (front + 1) % MAX;
}

/* DISPLAY */
void display() {
    if (isEmpty()) {
        printf("Queue Empty.\n");
        return;
    }

    printf("Queue Elements: ");
    int i = front;
    while (i != rear) {
        printf("%d ", cq[i]);
        i = (i + 1) % MAX;
    }
    printf("%d\n", cq[rear]);
}

/* REVERSE */
void reverse() {
    if (isEmpty()) {
        printf("Circular Queue Empty\n");
        return;
    }

    int temp[MAX], n = 0;
    int i = front;

    while (i != rear) {
        temp[n++] = cq[i];
        i = (i + 1) % MAX;
    }
    temp[n++] = cq[rear];

    i = front;
    for (int j = n - 1; j >= 0; j--) {
        cq[i] = temp[j];
        i = (i + 1) % MAX;
    }

    printf("Queue Reversed\n");
}

/* ASCENDING ORDER */
void ascending() {
    if (isEmpty()) {
        printf("Circular Queue Empty\n");
        return;
    }

    int temp[MAX], n = 0;
    int i = front;

    while (i != rear) {
        temp[n++] = cq[i];
        i = (i + 1) % MAX;
    }
    temp[n++] = cq[rear];

    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (temp[i] > temp[j]) {
                int t = temp[i];
                temp[i] = temp[j];
                temp[j] = t;
            }

    printf("Queue in Ascending Order: ");
    for (int i = 0; i < n; i++)
        printf("%d ", temp[i]);
    printf("\n");
}

/* MAX ELEMENT */
void maxElement() {
    if (isEmpty()) {
        printf("Circular Queue Empty\n");
        return;
    }

    int max = cq[front];
    int i = front;

    while (i != rear) {
        if (cq[i] > max)
            max = cq[i];
        i = (i + 1) % MAX;
    }
    if (cq[rear] > max)
        max = cq[rear];

    printf("Maximum element: %d\n", max);
}

/* MIN ELEMENT */
void minElement() {
    if (isEmpty()) {
        printf("Circular Queue Empty\n");
        return;
    }

    int min = cq[front];
    int i = front;

    while (i != rear) {
        if (cq[i] < min)
            min = cq[i];
        i = (i + 1) % MAX;
    }
    if (cq[rear] < min)
        min = cq[rear];

    printf("Minimum element: %d\n", min);
}

int main() {
    int choice, item;

    do {
        printf("\n1.Enqueue\n2.Dequeue\n3.Display\n4.Reverse\n5.Ascending\n6.Max\n7.Min\n8.Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter element: ");
                scanf("%d", &item);
                enqueue(item);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                display();
                break;
            case 4:
                reverse();
                break;
            case 5:
                ascending();
                break;
            case 6:
                maxElement();
                break;
            case 7:
                minElement();
                break;
            case 8:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice\n");
        }
    } while (choice != 8);

    return 0;
}
