#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define MAX 20
int queue[MAX],front=-1,rear=-1;

void enqueue(int n){
    if (rear==MAX-1) return;
    if (front==-1) front=0;
    queue[++rear]=n;
}

int dequeue(){
    if (front==-1 || front>rear) return -1;
    return queue[front++];
}

bool isEmpty(){
    return (front==-1 || front>rear);
}

void bfs(int adj[MAX][MAX],int n,int a){
    bool visit[MAX]={false};
    enqueue(a);
    visit[a]=true;
    printf("BFS Traversal starting from node %d: ",a);
    while(!isEmpty()){
        int node=dequeue();
        printf("%d ",node);
        for (int i=0;i<n;i++){
            if (adj[node][i] && !visit[i]){
                enqueue(i);
                visit[i]=true;
            }
        }
    }
}

int main(){
    int n,a;
    int adj[MAX][MAX];
    printf("Enter number of vertices: ");
    scanf("%d",&n);
    printf("Enter adjacency matrix: ");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&adj[i][j]);
        }
    }
    printf("Enter starting vertex: ");
    scanf("%d",&a);
    bfs(adj,n,a);
    return 0;
}