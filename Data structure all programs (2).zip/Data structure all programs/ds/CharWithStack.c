/*  Write a program to store and retrieve student information (USN, Name, Mobile Number) in Last In First Out (LIFO) order.*/

#include <stdio.h>
#include <string.h>

#define MAX 50

struct Student {
    char usn[20];
    char name[30];
    char mobile[15];
};

struct Student stack[MAX];
int top = -1;

void push() {
    if (top == MAX - 1) {
        printf("Stack Overflow\n");
        return;
    }
    top++;
    printf("Enter USN: ");
    scanf("%s", stack[top].usn);
    printf("Enter Name: ");
    scanf("%s", stack[top].name);
    printf("Enter Mobile Number: ");
    scanf("%s", stack[top].mobile);
}

void pop() {
    if (top == -1) {
        printf("Stack Underflow\n");
        return;
    }
    printf("\nRetrieved Student Details (LIFO):\n");
    printf("USN: %s\n", stack[top].usn);
    printf("Name: %s\n", stack[top].name);
    printf("Mobile: %s\n", stack[top].mobile);
    top--;
}

void display() {
    if (top == -1) {
        printf("Stack is empty\n");
        return;
    }
    printf("\nStudent Details (Top to Bottom):\n");
    for (int i = top; i >= 0; i--) {
        printf("USN: %s, Name: %s, Mobile: %s\n",
               stack[i].usn, stack[i].name, stack[i].mobile);
    }
}

int main() {
    int choice;

    do {
        printf("\n1. Push Student\n2. Pop Student\n3. Display Stack\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: push(); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: printf("Exiting...\n"); break;
            default: printf("Invalid choice\n");
        }
    } while (choice != 4);

    return 0;
}
