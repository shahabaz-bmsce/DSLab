#include <stdio.h>
#include <stdlib.h>

/* BST Node Structure */
struct Node {
    int data;
    struct Node *left;
    struct Node *right;
};

/* Create New Node */
struct Node* createNode(int x) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = x;
    newNode->left = newNode->right = NULL;
    return newNode;
}

/* a) Insert into BST */
struct Node* insert(struct Node *root, int x) {
    if (root == NULL)
        return createNode(x);

    if (x < root->data)
        root->left = insert(root->left, x);
    else if (x > root->data)
        root->right = insert(root->right, x);

    return root;
}

/* b) Inorder Traversal */
void inorder(struct Node *root) {
    if (root) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

/* b) Preorder Traversal */
void preorder(struct Node *root) {
    if (root) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

/* b) Postorder Traversal */
void postorder(struct Node *root) {
    if (root) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
}

/* c) Search a Value */
void search(struct Node *root, int key) {
    if (root == NULL) {
        printf("Element not found\n");
        return;
    }

    if (key == root->data) {
        printf("Element found\n");
    } else if (key < root->data) {
        search(root->left, key);
    } else {
        search(root->right, key);
    }
}

/* MAIN – Menu Driven */
int main() {
    struct Node *root = NULL;
    int choice, x;

    while (1) {
        printf("\n1.Insert\n2.Inorder\n3.Preorder\n4.Postorder\n5.Search\n6.Display\n7.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &x);
                root = insert(root, x);
                break;

            case 2:
                printf("Inorder Traversal: ");
                inorder(root);
                printf("\n");
                break;

            case 3:
                printf("Preorder Traversal: ");
                preorder(root);
                printf("\n");
                break;

            case 4:
                printf("Postorder Traversal: ");
                postorder(root);
                printf("\n");
                break;

            case 5:
                printf("Enter value to search: ");
                scanf("%d", &x);
                search(root, x);
                break;

            case 6:
                printf("Tree Elements (Inorder): ");
                inorder(root);
                printf("\n");
                break;

            case 7:
                return 0;

            default:
                printf("Invalid choice\n");
        }
    }
}
