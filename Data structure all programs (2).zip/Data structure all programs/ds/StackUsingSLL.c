#include <stdio.h>
#include <stdlib.h>

/* Node structure */
struct Node {
    int data;
    struct Node *next;
};

struct Node *top = NULL;

/* -------- CREATE NODE (SEPARATE) -------- */
struct Node* createNode(int item) {
    struct Node *newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation failed\n");
        return NULL;
    }
    newNode->data = item;
    newNode->next = NULL;
    return newNode;
}

/* -------- PUSH (INSERT) -------- */
void push(int item) {
    struct Node *newNode = createNode(item);
    if (newNode == NULL)
        return;

    newNode->next = top;
    top = newNode;
    printf("Pushed %d\n", item);
}

/* -------- POP -------- */
void pop() {
    if (top == NULL) {
        printf("Stack Underflow\n");
        return;
    }

    struct Node *temp = top;
    printf("Popped %d\n", temp->data);
    top = top->next;
    free(temp);
}

/* -------- DISPLAY -------- */
void display() {
    if (top == NULL) {
        printf("Stack is Empty\n");
        return;
    }

    struct Node *temp = top;
    printf("Stack elements:\n");
    while (temp != NULL) {
        printf("%d\n", temp->data);
        temp = temp->next;
    }
}

/* -------- MAIN -------- */
int main() {
    int choice, item;

    do {
        printf("\n1.Push\n2.Pop\n3.Display\n4.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter element: ");
                scanf("%d", &item);
                push(item);
                break;

            case 2:
                pop();
                break;

            case 3:
                display();
                break;

            case 4:
                printf("Exiting...\n");
                break;

            default:
                printf("Invalid choice\n");
        }
    } while (choice != 4);

    return 0;
}
