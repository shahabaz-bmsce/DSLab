#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node {
    char item[20];
    struct node *next;
} *SLL;

/* Create node */
SLL createNode(char name[]) {
    SLL n = (SLL)malloc(sizeof(struct node));
    strcpy(n->item, name);
    n->next = NULL;
    return n;
}

/* Insert at end */
SLL insertEnd(SLL head, char name[]) {
    SLL n = createNode(name);
    if (head == NULL)
        return n;

    SLL temp = head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = n;
    return head;
}

/* Insert at position (1-based) */
SLL insertAtPosition(SLL head, char name[], int pos) {
    SLL n = createNode(name);

    if (pos == 1) {
        n->next = head;
        return n;
    }

    SLL temp = head;
    for (int i = 1; i < pos - 1 && temp != NULL; i++)
        temp = temp->next;

    if (temp == NULL) {
        printf("Invalid position\n");
        free(n);
        return head;
    }

    n->next = temp->next;
    temp->next = n;
    return head;
}

/* Delete front */
SLL deleteFront(SLL head) {
    if (head == NULL) {
        printf("List is empty\n");
        return NULL;
    }
    SLL temp = head;
    head = head->next;
    free(temp);
    return head;
}

/* Delete rear */
SLL deleteRear(SLL head) {
    if (head == NULL) {
        printf("List is empty\n");
        return NULL;
    }

    if (head->next == NULL) {
        free(head);
        return NULL;
    }

    SLL temp = head;
    while (temp->next->next != NULL)
        temp = temp->next;

    free(temp->next);
    temp->next = NULL;
    return head;
}

/* Delete by item */
SLL deleteItem(SLL head, char key[]) {
    if (head == NULL)
        return NULL;

    if (strcmp(head->item, key) == 0) {
        SLL temp = head;
        head = head->next;
        free(temp);
        return head;
    }

    SLL cur = head;
    while (cur->next != NULL && strcmp(cur->next->item, key) != 0)
        cur = cur->next;

    if (cur->next != NULL) {
        SLL temp = cur->next;
        cur->next = temp->next;
        free(temp);
    }
    return head;
}

/* Display */
void display(SLL head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    while (head != NULL) {
        printf("%s -> ", head->item);
        head = head->next;
    }
    printf("NULL\n");
}

int main() {
    SLL head = NULL;
    int n, pos;
    char name[20];

    printf("Enter number of items: ");
    scanf("%d", &n);

    printf("Enter items:\n");
    for (int i = 0; i < n; i++) {
        scanf("%s", name);
        head = insertEnd(head, name);
    }

    printf("\nOriginal List:\n");
    display(head);

    printf("\nInsert item and position: ");
    scanf("%s %d", name, &pos);
    head = insertAtPosition(head, name, pos);
    display(head);

    head = deleteFront(head);
    printf("\nAfter Delete Front:\n");
    display(head);

    head = deleteRear(head);
    printf("\nAfter Delete Rear:\n");
    display(head);

    printf("\nEnter item to delete: ");
    scanf("%s", name);
    head = deleteItem(head, name);
    display(head);

    return 0;
}
