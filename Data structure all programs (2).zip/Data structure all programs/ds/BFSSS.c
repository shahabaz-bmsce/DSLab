#include <stdio.h>
#include <stdlib.h>

#define MAX 20

// Queue array and pointers
int queue[MAX];
int front = -1, rear = -1;

// Function to insert an element into the queue
void enqueue(int n) {
    // If queue is full, do nothing
    if (rear == MAX - 1)
        return;

    // If first insertion, initialize front
    if (front == -1)
        front = 0;

    // Insert element and move rear
    queue[++rear] = n;
}

// Function to remove an element from the queue
int dequeue() {
    // If queue is empty, return -1
    if (front == -1 || front > rear)
        return -1;

    // Return element and move front
    return queue[front++];
}

// Function to check whether queue is empty
int isEmpty() {
    // Queue is empty if front is -1 or front crossed rear
    return (front == -1 || front > rear);
}

// BFS traversal function
void bfs(int adj[MAX][MAX], int n, int a) {

    // Array to mark visited vertices
    // 0 = not visited, 1 = visited
    int visit[MAX] = {0};

    // Insert starting node into queue
    enqueue(a);

    // Mark starting node as visited
    visit[a] = 1;

    printf("BFS Traversal starting from node %d: ", a);

    // Continue while queue is not empty
    while (!isEmpty()) {

        // Remove a vertex from queue
        int node = dequeue();

        // Print the current vertex
        printf("%d ", node);

        // Check all adjacent vertices
        for (int i = 0; i < n; i++) {

            // If there is an edge and vertex is not visited
            if (adj[node][i] && !visit[i]) {

                // Add vertex to queue
                enqueue(i);

                // Mark vertex as visited
                visit[i] = 1;
            }
        }
    }
}

int main() {
    int n, a;
    int adj[MAX][MAX];

    // Read number of vertices
    printf("Enter number of vertices: ");
    scanf("%d", &n);

    // Read adjacency matrix
    printf("Enter adjacency matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }

    // Read starting vertex
    printf("Enter starting vertex: ");
    scanf("%d", &a);

    // Call BFS function
    bfs(adj, n, a);

    return 0;
}
